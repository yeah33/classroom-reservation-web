$( function() {
    $("#datepicker").datepicker();
});